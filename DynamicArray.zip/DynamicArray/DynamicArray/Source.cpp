#include <iostream>
#include "DynamicArray.h"

int main()
{
	DynamicArray<int> dArr(3);

	dArr.push(10);
}