#pragma once
template<typename T>
class DynamicArray
{
public:
	DynamicArray(int size) 
	{
		m_allocatedElements = size;
		m_array = new T[m_allocatedElements];
	}

	void push(T val)
	{
		if (m_usedElements >= m_allocatedElements)
		{
			Resize();
		}

		m_array[m_usedElements] = val;

		m_usedElements++;
	}

	void pop()
	{

	}

	void Resize()
	{
		
	}

	//void E

	~DynamicArray()
	{
		delete[] m_array;
	}

private:

	T * m_array;
	int m_allocatedElements;
	int m_usedElements;
};

